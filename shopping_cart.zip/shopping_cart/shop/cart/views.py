from django.shortcuts import render
from django.views.generic import ListView, DetailView, CreateView, DeleteView
from cart.models import Product, FlipkartVideo
from cart.forms import ProductForm

# Create your views here.
class ProductListView(ListView):
    model = Product

class ProductDetailView(DetailView):
    model = Product

class ProductCreateView(CreateView):
    login_url = '/login/'
    redirect_field_name = 'cart/product_detail.html'
    form_class = ProductForm

    model = Product


class ProductDeleteView(DeleteView):
    model = Product
    success_url = '/login/'


# # Video work
# class VideoListView(ListView):
#     model = FlipkartVideo

from .models import FlipkartVideo

def display_video(request):
    videos = FlipkartVideo.objects.all()
    context = {'videos': videos}
    return render (request, 'cart/product_list.html', context)