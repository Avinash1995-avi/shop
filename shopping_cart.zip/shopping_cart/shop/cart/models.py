from django.db import models
from django.urls import reverse
from embed_video.fields import EmbedVideoField

# Create your models here.
class Product(models.Model):
    name = models.CharField(max_length=100)
    image = models.ImageField(upload_to="", default='Nothing')
    price = models.DecimalField(max_digits=6, decimal_places=2)
    rating = models.DecimalField(max_digits=2, decimal_places=1)
    address = models.TextField()

    def get_absolute_url(self):
        return reverse('product_detail', kwargs={'pk' :self.pk})

    def __str__(self):
        return self.name

    
class FlipkartVideo(models.Model):
    vid = EmbedVideoField(blank=True)

    def __str__(self):
        return self.vid
