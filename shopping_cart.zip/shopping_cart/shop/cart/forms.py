from django.contrib.auth.forms import AuthenticationForm
from django import forms

#Customizing the Default Login Authentication Form
class UserLoginForm(AuthenticationForm):
    def __init__(self, *args, **kwargs):
        super(UserLoginForm, self).__init__(*args, **kwargs)

    username = forms.CharField(widget=forms.TextInput(
        attrs={'class': 'form-control'}))
    password = forms.CharField(widget=forms.PasswordInput(
        attrs={
            'class': 'form-control'
        }
))


from cart.models import Product

class ProductForm(forms.ModelForm):
    image = forms.ImageField(required=False)

    class Meta:
        model = Product
        fields = ('name', 'image', 'price', 'rating', 'address')

        widgets = {
            'name' : forms.TextInput(attrs= {'class' : 'textinputclass'}),
            'address' : forms.Textarea(attrs={'class': 'editable medium-editor-textarea postcontent'}),
            'price': forms.TextInput(attrs= {'class' : 'textinputclass'}),
            'rating': forms.TextInput(attrs= {'class' : 'textinputclass'}),

        }